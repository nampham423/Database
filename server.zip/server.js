const express = require('express');
const oracledb = require('oracledb');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*'); // Allow all origins
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});
const dbConfig = {
    user: "dbhosp3", password: "psw", connectionString: "localhost:1521"
};

app.post('/login', async (req, res) => {
    let connection;
    const loginid = req.body;
    try {
        connection = await oracledb.getConnection(dbConfig);
        console.log(loginid.username, loginid.password);
        const query = `SELECT * FROM login WHERE username = :id AND pass = :pass`;
        console.log(query); // Check the generated SQL query
        
        let result = await connection.execute(
            `SELECT * FROM login WHERE username = :id AND pass = :pass`,
            { 
                id: loginid.username,  
                pass: loginid.password       
            },
        );
        console.log("Kết quả truy vấn:", result.rows);
        if (result.rows.length > 0) {
            // Doctor found
            res.json({ found: true});
        } else {
            // Doctor not found
            res.json({ found: false });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: err.message });
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error(err);
            }
        }
    }
});
app.post('/add_patient', async (req, res) => {
    let connection;
    try {
        console.log('Connecting to database...');
        connection = await oracledb.getConnection(dbConfig);
        console.log('Database connection successful.');

        const { phone_number, p_fname, p_lname, gender, dob, address, op_id, ip_id } = req.body;
        // In ra console các giá trị trước khi thêm vào cơ sở dữ liệu
        console.log(req.body);

        console.log('Preparing to insert patient data...');
        console.log('Phone Number:', phone_number);
        console.log('First Name:', p_fname);
        console.log('Last Name:', p_lname);
        console.log('Gender:', gender);
        console.log('DOB:', dob);
        console.log('Address:', address);
        console.log('OP ID:', op_id === 'on' ? 'Y' : 'N');
        console.log('IP ID:', ip_id === 'on' ? 'Y' : 'N');
        
        console.log('Inserting patient data into database...');
        let result = await connection.execute(
            `INSERT INTO Patient(phone_number, Fname, Lname, gender, DOB, address, OP_flag, IP_flag) VALUES (:phone_number, :Fname, :Lname, :gender, TO_DATE(:DOB, 'YYYY-MM-DD'), :address, :OP_flag, :IP_flag)`, 
            {
                phone_number: phone_number,
                Fname: p_fname,
                Lname: p_lname,
                gender,
                DOB: dob,
                address,
                OP_flag: op_id === 'on' ? 'Y' : 'N',
                IP_flag: ip_id === 'on' ? 'Y' : 'N'
            },
            { autoCommit: true }
        );
        console.log('Patient added successfully:', result);

        result = await connection.execute(
            `SELECT * FROM Patient WHERE phone_number = :phone_number`, 
            {
                phone_number: phone_number,
            },
        );
        console.log('Patient output:', result);

        res.status(200).json({ message: "Patient added successfully", result });
    } catch (err) {
        console.error('Error during database operation:', err);
        res.status(500).json({ message: "Error adding patient", err });
    } finally {
        if (connection) {
            try {
                console.log('Closing database connection...');
                await connection.close();
                console.log('Database connection closed.');
            } catch (err) {
                console.error('Error closing connection:', err);
            }
        }
    }
});
app.post('/search_doctor', async (req, res) => {
    let connection;
    const doctorId = req.body.doctorId;
    console.log('Search ID:', doctorId);
    try {
        connection = await oracledb.getConnection(dbConfig);
    
        let result = await connection.execute(
            `SELECT * FROM employee WHERE emp_ID = :eID AND Dr_Flag = 'Y'`,
            { eID: doctorId },
        );

        console.log("Kết quả truy vấn:", result.rows);
        if (result.rows.length > 0) {
            // Doctor found
            res.json({ found: true});
        } else {
            // Doctor not found
            res.json({ found: false });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: err.message });
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error(err);
            }
        }
    }
});
app.post('/get_patient_info', async (req, res) => {
    let connection;
    try {
        console.log("Attempting database connection...");
        connection = await oracledb.getConnection(dbConfig);
        console.log("Database connected.");

        const doctorId = req.body.Dr_ID;
        console.log("Received Doctor ID:", doctorId);

        console.log("Executing PL/SQL function...");
        const result = await connection.execute(
            `BEGIN :cursor := get_patientInf_by_DrID(:Dr_id); END;`,
            {
                Dr_id: doctorId,
                cursor: { type: oracledb.CURSOR, dir: oracledb.BIND_OUT }
            }
        );

        const resultSet = result.outBinds.cursor;
        console.log("Fetching rows from cursor...");
        const rows = await resultSet.getRows();
        console.log("Rows fetched:", rows);

        if (rows.length > 0) {
            console.log("Patients found, sending data.");
            res.json({ found: true, patients: rows });
        } else {
            console.log("No patients found.");
            res.json({ found: false });
        }

        await resultSet.close();
        console.log("ResultSet closed.");

    } catch (err) {
        console.error("Error occurred:", err);
        console.error("Error stack:", err.stack);
        res.status(500).send({ error: err.message });
    } finally {
        if (connection) {
            try {
                await connection.close();
                console.log("Database connection closed.");
            } catch (err) {
                console.error("Error closing database connection:", err);
            }
        }
    }
});

app.post('/search_patient', async (req, res) => {
    let { searchValue } = req.body;
    let connection;

    try {
        connection = await oracledb.getConnection(dbConfig);

        // Query for Patient details
        let patientQuery = `SELECT * FROM Patient WHERE phone_number = :searchValue OR OP_id = :searchValue OR IP_id = :searchValue`;
        let patientResult = await connection.execute(patientQuery, { searchValue }, { outFormat: oracledb.OUT_FORMAT_OBJECT });

        // If patient exists, query for Treatment, Examination, and Admission_History
        if (patientResult.rows.length > 0) {
            let treatmentQuery = `SELECT * FROM Treatment WHERE IP_phone = :searchValue`;
            let examinationQuery = `SELECT * FROM Examination WHERE OP_phone = :searchValue`;
            let admissionHistoryQuery = `SELECT * FROM Admission_History WHERE IP_phone = :searchValue`;

            let treatmentResult = await connection.execute(treatmentQuery, { searchValue }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
            let examinationResult = await connection.execute(examinationQuery, { searchValue }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
            let admissionHistoryResult = await connection.execute(admissionHistoryQuery, { searchValue }, { outFormat: oracledb.OUT_FORMAT_OBJECT });

            // Combine results
            let combinedResult = {
                patient: patientResult.rows,
                treatment: treatmentResult.rows,
                examination: examinationResult.rows,
                admissionHistory: admissionHistoryResult.rows
            };
            res.json(combinedResult);
            console.log(combinedResult);
        } else {
            res.status(404).send({ message: "Patient not found." });
        }

    } catch (err) {
        console.error('Error executing query:', err);
        res.status(500).send({ error: err.message });
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error('Error closing connection:', err);
            }
        }
    }
});


//---------------------------------------------------------//
//RESTFUL API, gọi cái này để vào trang detail patient
app.get('/patient/:phone', async (req, res) => {
    const { phone } = req.params;
    console.log(phone);
    // Render the EJS template with the retrieved data
    res.render('Detail_Patient', { data : phone });

});

// API mà Detail Patient gọi để lấy inf bỏ vào table
app.get('/patient/:phone/OP_info', async (req, res) => {
    const phone = req.params.phone;
    console.log('Patient Phone number:', phone);
    let connection;

    try {
        connection = await oracledb.getConnection(dbConfig);
    
        let result = await connection.execute(
            `SELECT DISTINCT record_ID, Dr_ID, diagnosis, fee, 
            OP_Phone, TO_CHAR(exam_date, 'yyyy-mm-dd') exam_date
            FROM Treatment_history NATURAL JOIN Examination
            WHERE OP_phone = :phone_t
            ORDER BY record_ID`,
            { phone_t: phone }
        );

        console.log("Kết quả truy vấn:", result.rows);
        if (result.rows.length > 0) {
            res.json({ data: result.rows });
        } 
        //else {     }
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: err.message });
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error(err);
            }
        }
    }
});

// API cũng cái Detail Patient gọi để lấy ID và record hiện tại
app.get('/patient/:phone/new_OP_info', async (req, res) => {
    const phone = req.params.phone;
    console.log('Patient Phone number:', phone);
    let connection;
    const bind1 = {phone_t: phone};

    try {
        connection = await oracledb.getConnection(dbConfig);
    
        // Đầu tiên lấy OP ID đã
        let result = await connection.execute(
            `SELECT OP_FLAG, OP_ID  FROM PATIENT
            WHERE phone_number = :phone_t`, bind1
        );
        
        let OP_ID;
        console.log("Query đầu tiên:", result.rows);
        if (result.rows.length > 0) { //tồn tại 
            let data = result.rows[0]; //coi như nó chỉ có 1 row
            console.log("Tồn tại sdt:", data);
            if(data[0] === 'Y') //có OP_ID rồi
            { 
                OP_ID = data[1];
                console.log("Có sẵn OP_ID:", OP_ID);
                // Có rồi thì lấy max record_id, làm data để return 
                let max_record = await connection.execute(
                    `SELECT MAX(record_id) FROM Treatment_history
                    WHERE OP_phone = :phone_t`,bind1
                );
                console.log("max record_id:", max_record);

                if (max_record.rows.length > 0){ //Nếu đã có bệnh án trc đó
                    //return max_record + 1
                    return res.json({ record: max_record.rows[0][0] + 1, OP_ID: OP_ID });
                } else { //chưa có rec nào
                    return res.json({ record: 1, OP_ID: OP_ID });
                }
            } else { //Nếu chưa có 
                // Bật flag
                console.log("Chưa có OP_ID! Bật Flag");
                await connection.execute(
                    `UPDATE PATIENT  SET OP_FLAG = 'Y'
                    WHERE phone_number = :phone_t`,
                    bind1, { autoCommit: true } 
                );
                // Lấy ID mới tạo
                result = await connection.execute(
                    `SELECT OP_ID  FROM PATIENT
                    WHERE phone_number = :phone_t`, bind1
                );
                OP_ID = result.rows[0][0];
                console.log("Cấp OP_ID mới:", OP_ID);
                // Tất nhiên rec sẽ là 1, đầu tiên
                return res.json({ record: 1, OP_ID: OP_ID});
            }
            // Sau khi bật flag rồi
            res.json({ data: OP_ID });
        } 
        //else {     }
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: err.message });
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error(err);
            }
        }
    }
});

// API Detail Patient gọi để update Treatment_history
app.post('/OP/new_rec', async (req, res) => {
    try {
        const binds = { 
            RECORD_ID : req.body.RECORD_ID, 
            OP_PHONE: req.body.OP_PHONE, 
            DR_ID: req.body.DR_ID };
            
        // Insert the database with the new values
        const connection = await oracledb.getConnection(dbConfig);
        await connection.execute(
          `INSERT INTO Treatment_history(RECORD_ID, OP_PHONE, DR_ID) 
          VALUES(:RECORD_ID, :OP_PHONE, :DR_ID)`,
          binds, { autoCommit: true }
        );
          
        //Also insert into Examination
        await connection.execute(
          `INSERT INTO Examination(RECORD_ID, OP_PHONE, DR_ID) 
          VALUES(:RECORD_ID, :OP_PHONE, :DR_ID)`,
          binds, { autoCommit: true }
        );

        // Release the connection
        await connection.close();
          
        //Redirect back to the data page with the updated information
        res.redirect(`/patient/${binds.OP_PHONE}`);
      } catch (error) {
        console.error('Error insert Treatment_history:', error);
        res.status(500).send('Internal Server Error');
    } 
});

// get route, nó render lên cái page
app.get('/patient/detail_OP/:phone/:record_ID', async (req, res) => {   
    const { phone, record_ID } = req.params;
    console.log(phone, record_ID);

    try {
        // Retrieve parameters from the request
            
        let connection = await oracledb.getConnection(dbConfig);
    
        let result = await connection.execute(
            `SELECT DR_ID, OP_PHONE, RECORD_ID,
            TO_CHAR(exam_date, 'yyyy-mm-dd') EXAM_DATE, DIAGNOSIS, 
            TO_CHAR(next_exam, 'yyyy-mm-dd') NEXT_EXAM, FEE 
            FROM Examination
            WHERE OP_phone = :phone_t AND record_id = :rec`,
            { phone_t: phone, rec: record_ID }
        );
    
        console.log("Kết quả truy vấn:", result.rows);

        // Process the result
        const detailData = result.rows; //
    
        await connection.close();
    
        // Render the EJS template with the retrieved data
        res.render('Outpatient_detail', { data : detailData });
    } catch (error) {
        console.error('Error fetching detailed information:', error);
        res.status(500).send('Internal Server Error');
    }
});    

// Update route for handling POST requests
app.post('/updateOP', async (req, res) => {
    try {
      const { DR_ID, OP_PHONE, RECORD_ID, EXAM_DATE, UP_EXAM_DATE, UP_NEXT_EXAM, UP_DIAG, UP_FEE } = req.body;
          
      // Update the database with the new values
      const connection = await oracledb.getConnection(dbConfig);
  
      await connection.execute(
        `UPDATE EXAMINATION 
        SET EXAM_DATE = TO_DATE(:UP_EXAM_DATE_t, 'yyyy-mm-dd'),
        NEXT_EXAM = TO_DATE(:UP_NEXT_EXAM_t, 'yyyy-mm-dd'), 
        DIAGNOSIS = :UP_DIAG_t, FEE = :UP_FEE_t
        WHERE DR_ID = :DR_ID_t AND OP_PHONE = :OP_PHONE_t AND RECORD_ID = :RECORD_ID_t 
        AND EXAM_DATE = TO_DATE(:EXAM_DATE_t, 'yyyy-mm-dd')`,
        {
            DR_ID_t: DR_ID, OP_PHONE_t: OP_PHONE, RECORD_ID_t: RECORD_ID, 
            EXAM_DATE_t: EXAM_DATE, UP_EXAM_DATE_t: UP_EXAM_DATE, 
            UP_NEXT_EXAM_t: UP_NEXT_EXAM, UP_DIAG_t: UP_DIAG, UP_FEE_t: UP_FEE
        }, 
        { autoCommit: true }
      );
  
      // Release the connection
      await connection.close();
        
      //Redirect back to the data page with the updated information
      res.redirect(`/patient/${OP_PHONE}`);
    } catch (error) {
      console.error('Error updating details:', error);
      res.status(500).send('Internal Server Error');
    }
  }
);
  

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
